import random

#Printanje table
def print_tabla(tabla):

    n = len(tabla)
    for red in tabla:
        print(" | ".join(red))
        print("-" * (4 * n - 1))

#Provjera tko je dobio igru
def provjera_pobjednika(tabla, igrac):

    n = len(tabla)

    # Provjera redova
    for red in tabla:
        if all(celija == igrac for celija in red):
            return True

    # Provjera stupaca
    for stupac in range(n):
        if all(tabla[red][stupac] == igrac for red in range(n)):
            return True

    # Provjera dijagonala
    if all(tabla[i][i] == igrac for i in range(n)) or all(tabla[i][n-i-1] == igrac for i in range(n)):
        return True
    return False

#Gledamo jesu li sve ćelije zauzete
def puna(tabla):
    for red in tabla:
        if any(celija == " " for celija in red):
            return False
    return True

#Kompjuter randomizirano igra
def kompjuterovaigra(tabla):
    n = len(tabla)
    moguca_igra = [(red, stupac) for red in range(n) for stupac in range(n) if tabla[red][stupac] == " "]
    return random.choice(moguca_igra)

def igra():
    print("NxN Tic-Tac-Toe!")

    while True:
        try:
            n = int(input("Upišite veličinu table kakvu želite igrati (N): "))
            if n < 3:
                print("Veličina table mora biti jednaka ili veća od broja 3")
                continue
        except ValueError:
            print("Ne valjan unos. Molimo Vas da unesete valjan broj koji je jednak ili veći od broja 3.")
            continue
        else:
            break

    #Radimo tablicu da bi je mogli "punit" sa X ili O

    tabla = [[" " for _ in range(n)] for _ in range(n)]

    #Biramo zelimo li igrati sa X ili O

    while True:
        igrac = input("Odaberite X ili O (Igrač koji je odabrao X igra prvi): ").upper()
        if igrac not in ["X", "O"]:
            print("Ne valjan unos. Molimo Vas da upišete X ili O.")
        else:
            break

    #Radimo listu sa X ili O. Defaultno je stavljeno da je X = [0] (prvi igrac), O = [1] (drugi igrac)

    igraci = ["X", "O"]

    #Ali mi to mozemo promijeniti ako odlučimo igrati sa O

    if igrac == "O":
        igraci = ["O", "X"]

    while True:

        # Igrač igra
        print_tabla(tabla)

        print(f"Sada igra igrač: {igraci[0]}.")
        while True:
            try:
                red = int(input("Upišite red koji želite igrati: "))
                stupac = int(input("Upišite stupac koji želite igrati: "))
                if red < 1 or red > n or stupac < 1 or stupac > n:
                    print("Netočan unos. Broj reda ili stupca ne smije biti veći od veličine table te ne smije biti manji od 1.")
                    continue
                if tabla[red - 1][stupac - 1 ] != " ":
                    print("Odabrana ćelija je već zauzeta. Odaberite drugu ćeliju.")
                    continue
            except ValueError:
                print("Ne valjan unos. Molimo Vas da unesete valjan broj.")
                continue
            else:
                break

        tabla[red - 1][stupac -1] = igraci[0]

        #Gledamo tko je pobjedio ili je izjednačeno

        if provjera_pobjednika(tabla, igraci[0]):
            print_tabla(tabla)
            print(f"{igraci[0]} je pobjedio!")
            break

        if puna(tabla):
            print_tabla(tabla)
            print("Izjednačena igra!")
            break

        # Kompjuter igra

        print_tabla(tabla)
        print("Kompjuterov red.")

        red, stupac = kompjuterovaigra(tabla)
        tabla[red][stupac] = igraci[1]

        if provjera_pobjednika(tabla, igraci[1]):
            print_tabla(tabla)
            print("Kompjuter je pobjedio!")
            break

        if puna(tabla):
            print_tabla(tabla)
            print("Izjednačena igra!")
            break

    #Kad završi igra odlučujemo hoćemo li igrati ponovno ili ne.

    play_again = input("Želite li ponovno igrati (da ili ne): ").lower()
    if play_again == "da":
        igra()
    else:
        print("Hvala na igranju!")

if __name__ == "__main__":
    igra()